import java.awt.print.Book;

public class Main {
    public static void main(String[] args) {
        createBook();
        System.out.println("Hello world");
        int age=10;
        String name="Abhishek";
        System.out.println(name);


    }

    private static void createBook() {
        Books b1=new Books("Learn Html",400F);

       /* b1.price=300f;
        b1.title="Learn Java";*/

       // b1.setPrice(-300F);
        new Books();//only objects
        Books b2;//only reference
        b2=new Books();



    }
}
