public interface IBook {
    public void deposit();
}
