public class STATUS {

    public static STATUS issued;
    public static STATUS available;
    public static STATUS damaged;
}
